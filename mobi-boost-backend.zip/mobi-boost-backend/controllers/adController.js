const Ad = require('../models/Ad');

exports.getAds = async (req, res, next) => {
  try {
    const ads = await Ad.find().sort({ createdAt: 1 });
    res.json(ads.map(a => ({ id: a._id.toString(), title: a.title, image: a.image })));
  } catch (error) {
    next(error);
  }
};

exports.addAd = async (req, res, next) => {
  try {
    const { title, image } = req.body;
    if (!title || !image) {
      return res.status(400).json({ message: '⚠️ العنوان والصورة/الـ GIF مطلوبين' });
    }
    const ad = await Ad.create({ title, image });
    res.status(201).json({
      message: '🎬 تم إضافة الإعلان بنجاح',
      ad: { id: ad._id.toString(), title: ad.title, image: ad.image }
    });
  } catch (error) {
    next(error);
  }
};

exports.deleteAd = async (req, res, next) => {
  try {
    const deleted = await Ad.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: '⚠️ الإعلان غير موجود' });
    res.json({ message: '🗑️ تم حذف الإعلان بنجاح' });
  } catch (error) {
    next(error);
  }
};